/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao2;

import javax.swing.JOptionPane;

/**
 *
 * @author gabriel
 */
public class Questao2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int ingresso_meia;
        int ingresso_int;
        double preco;
        String classe = JOptionPane.showInputDialog("Escolha a classe que deseja\nA: R$ 500,00\nB: R$ 200,00\nC:R$ 60,00");
        
        if("A".equals(classe) || "a".equals(classe)){
            ingresso_meia=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de ingressos à meia entrada que deseja comprar"));
            ingresso_int=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de ingressos à meia entrada que deseja comprar"));
            preco=((ingresso_meia*250))+(ingresso_int*500);
            JOptionPane.showMessageDialog(null, "Valor total = R$"+preco);
        }
        if("B".equals(classe) || "b".equals(classe)){
            ingresso_meia=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de ingressos à meia entrada que deseja comprar"));
            ingresso_int=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de ingressos à meia entrada que deseja comprar"));
            preco=((ingresso_meia*100))+(ingresso_int*200);
            JOptionPane.showMessageDialog(null, "Valor total = R$"+preco);
        }
        if("C".equals(classe) || "c".equals(classe)){
            ingresso_meia=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de ingressos à meia entrada que deseja comprar"));
            ingresso_int=Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de ingressos à meia entrada que deseja comprar"));
            preco=((ingresso_meia*30))+(ingresso_int*60);
            JOptionPane.showMessageDialog(null, "Valor total = R$"+preco);
        }
        
        
    }
    
}
