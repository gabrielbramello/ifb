/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao1;

import java.util.*;

/**
 *
 * @author gabriel
 */
public class Questao1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random r = new Random();
        int[] numeros = new int[50];
        int[] numerosOrdenados = new int[50];
        
        for(int i=0; i<50; i++){
            numeros[i]=r.nextInt(100);
        } 
        
        Ordenacao a = new Ordenacao();
        
        numerosOrdenados=a.bubbleSort2(numeros);
        
        for(int i=0; i<50; i++){
            if(i>=1 && numerosOrdenados[i]==numerosOrdenados[i-1]){
                while(numerosOrdenados[i]==numerosOrdenados[i-1]){
                    numerosOrdenados[i]=r.nextInt(100);
                    numeros=numerosOrdenados;
                    numerosOrdenados=a.bubbleSort2(numeros);
                }
                i=0;
            }
        }
        for(int i=0; i<50; i++){
            System.out.println(numerosOrdenados[i]);
        }
    }
    
}

class Ordenacao{
    int[] bubbleSort2(int[] array) {
        int swap;
        for(int j = array.length-1; j > 1 ; j--) {
            for(int i = 0; i < j; i++) {
                if(array[i] > array[i+1]) {
                    swap = array[i];
                    array[i] = array[i+1];
                    array[i+1] = swap;
                }
            }
        }
        return array;
    }
}