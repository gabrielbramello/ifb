/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho3;

import javax.swing.JOptionPane;

/**
 *
 * @author gabriel
 */
public class Trabalho3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Hanoi a = new Hanoi();
        int discos = Integer.parseInt(JOptionPane.showInputDialog("Digite o número de discos"));
        JOptionPane.showMessageDialog(null, "Para movimentar "+discos+" discos são necessários "+a.funcaoHanoi(discos)+" segundos");
        a.contaMovimento(discos, "Haste1", "Haste2", "Haste3");        
    }
    
}

class Hanoi{
    int discos;
    void contaMovimento(int discos, String origem, String aux, String destino){
        if(discos>0){
            contaMovimento(discos-1, origem, destino, aux);
            JOptionPane.showMessageDialog(null,"Mover da "+origem+" para "+destino+"\n");
            contaMovimento(discos-1, aux, origem, destino);
        }
    }
    
    double funcaoHanoi(int discos){
        double funcao;
        funcao=(2*((Math.pow(2, discos-1))-1))+1;
        return funcao;
    }
}

