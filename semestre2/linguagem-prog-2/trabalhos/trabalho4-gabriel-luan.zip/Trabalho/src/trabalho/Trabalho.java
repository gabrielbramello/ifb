/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho;

import java.util.Random;

/**
 *
 * @author Luan Kol & Gabriel Mello
 */
public class Trabalho {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Functions f = new Functions();
        Random r = new Random();
        int[] array = new int[100];
        for (int i = 0; i < array.length; i++) {
            array[i] = r.nextInt(101);
        }
        for (int i = 0; i <array.length; i++) {
            System.out.print(array[i]+" ");
            if(i==(array.length-1)){
                System.out.println("");
            }
        }
        System.out.println("Maior = "+f.maior(array));
        System.out.println("Menor = "+f.menor(array));
        System.out.println("Soma de Todos os Termos = "+f.soma(array));
        System.out.println("Média Aritimética = "+f.media(f.soma(array), array));
        System.out.println("Desvio Padrão = "+f.desvioPadrao(f.media(f.soma(array), array), array));
        System.out.println("Variância = "+f.desvioPadrao(f.media(f.soma(array), array), array)*f.desvioPadrao(f.media(f.soma(array), array), array));
        System.out.println("Mediana = "+f.insertionSort(array));
        System.out.println("Modo = "+f.modo(array));
    }
    static class Functions{
        int maior(int[] array){
            int maior = 0;
            for (int i = 0; i < array.length; i++) {
                if(array[i]>maior){
                    maior = array[i];
                }
            }
            return maior;
        }
        
        int menor(int[] array){
            int menor = 101;
            for (int i = 0; i < array.length; i++) {
                if(menor>array[i]){
                    menor = array[i];
                }                
            }
            return menor;
        }
        
        int soma(int[] array){
            int soma = 0;
            for (int i = 0; i < array.length; i++) {
                soma = soma + array[i];                
            }
            return soma;
        }
        
        float media(int soma, int[] array){
            float media = (float) (soma / array.length);
            return media;
        }
        
        float desvioPadrao(float media, int[] array){
            float somatoria = 0;
            for (int i = 0; i < array.length; i++) {
                somatoria += Math.pow((array[i] - media), 2);
        }
        float desvioPadrao = (float) Math.sqrt((1 / (array.length - 1.0) )* somatoria);
        return desvioPadrao;
        }
        
        int insertionSort(int[] array) {
        int swap;
        int j;
        for(int i = 1; i < array.length; i++) {
            j = i;
            swap = array[i];
            while((j > 0)&&(swap < array[j-1])) {
                array[j] = array[j-1];
                j--;
            }
            array[j] = swap;
        }
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]+" ");
            if(i==(array.length-1)){
                System.out.println("");
            }
        }
        int mediana = array[49];
        return mediana;
        }
      
        int modo(int[] array) {
        int modo = 0;
        int[] amostra = new int[101];
        for (int i = 0; i < amostra.length; i++) {
            amostra[i] = 0;
        }
        for (int i = 0; i < array.length; i++) {
            amostra[array[i]]++;
        }
        int quantModo = 0;
        for (int i = 0; i < amostra.length; i++) {
            if(amostra[i] > quantModo) {
                quantModo = amostra[i];
                modo = i;
            }
        }
        return modo;
    }
    }
}
