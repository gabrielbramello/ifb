<!DOCTYPE html>
<html>
<head>
	<title>Questão 3</title>
</head>
<body>
	<?php 
		$frase = "PHP é uma linguagem interpretada para web";
		$a = explode(" ", $frase);
		echo $a[0].'<br>';
		echo $a[1].'<br>';
		echo $a[2].'<br>';
		echo $a[3].'<br>';
		echo $a[4].'<br>';
		echo $a[5].'<br>';
		echo $a[6].'<br>';
	 ?>

</body>
</html>