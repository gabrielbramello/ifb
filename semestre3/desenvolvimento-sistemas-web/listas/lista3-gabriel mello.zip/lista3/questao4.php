<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $nome='Gabriel';
            $sobrenome='Mello';

            echo $nome;
            echo "<br />";
            echo $sobrenome;
            echo "<br /> ";

            $nomesobrenome=$nome.$sobrenome;

            echo $nomesobrenome;
        ?>

    </body>
</html>
