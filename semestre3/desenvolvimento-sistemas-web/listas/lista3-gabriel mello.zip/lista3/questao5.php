<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <?php
            $farenh=40;
            $celsius = (5/9)*($farenh-32);
            echo $celsius;
        ?>
    </body>
</html>
